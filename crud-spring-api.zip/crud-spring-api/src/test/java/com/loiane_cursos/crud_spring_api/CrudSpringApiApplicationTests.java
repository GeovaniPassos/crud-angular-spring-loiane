package com.loiane_cursos.crud_spring_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudSpringApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
